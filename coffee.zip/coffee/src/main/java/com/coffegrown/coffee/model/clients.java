package com.coffegrown.coffee.model;

import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table; // Opcional, pero recomendable


@Entity
@Table(name="clientes")
public class clients{
    @Id             
    @Column(name="client_id")
    private int client_id;
    
    @Column(name="clientName", length=100, nullable=false)
    private String clientName;

    @Column(name="type", length=50, nullable=false)
    private String type;

    @Column(name="country", length=100, nullable=false)
    private String country;

    @ManyToOne
    @JoinColumn(name="order_id", referencedColumnName="order_id", nullable=false)
    private Orders order;

    // Constructor vacío
    public clients() {
    }                                       

    public clients(int client_id, String clientName, String type, String country, Orders order) {
        this.client_id = client_id;
        this.clientName = clientName;
        this.type = type;
        this.country = country;
        this.order = order;
    }

    // Getters y Setters
    public int getClient_id() {
        return client_id;
    }

    public void setClient_id(int client_id) {
        this.client_id = client_id;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public Orders getOrder() {
        return order;
    }

    public void setOrder(Orders order) {
        this.order = order;
    }
}