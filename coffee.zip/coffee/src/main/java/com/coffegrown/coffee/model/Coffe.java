package com.coffegrown.coffee.model;

import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import jakarta.persistence.*;

@Entity 
@Table(name="coffee")   
public class Coffe {  // Nombre de la clase corregido
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="coffee_id")
    private int coffeeId;

    @Column(name="coffeeType", length=100, nullable=false)
    private String coffeeType;

    @Column(name="quality", length=100, nullable=false)
    private String quality;

    @Column(name="variety", length=100, nullable=false)
    private String variety;

    @Column(name="harvest_date", length=50, nullable=false)
    private String harvestDate;

    @ManyToOne
    @JoinColumn(name="process_id", referencedColumnName="process_id", nullable=false)
    private Process process;

    @ManyToOne
    @JoinColumn(name="farm_id", referencedColumnName="farm_id", nullable=false)
    private Farms farm;

    // Constructor vacío
    public Coffe() {}

    // Constructor con parámetros
    public Coffe(int coffeeId, String coffeeType, String quality, String variety, String harvestDate, Process process, Farms farm) {
        this.coffeeId = coffeeId;
        this.coffeeType = coffeeType;
        this.quality = quality;
        this.variety = variety;
        this.harvestDate = harvestDate;
        this.process = process;
        this.farm = farm;
    }

    // Getters y Setters
    public int getCoffeeId() {
        return coffeeId;
    }

    public void setCoffeeId(int coffeeId) {
        this.coffeeId = coffeeId;
    }

    public String getCoffeeType() {
        return coffeeType;
    }

    public void setCoffeeType(String coffeeType) {
        this.coffeeType = coffeeType;
    }

    public String getQuality() {
        return quality;
    }

    public void setQuality(String quality) {
        this.quality = quality;
    }

    public String getVariety() {
        return variety;
    }

    public void setVariety(String variety) {
        this.variety = variety;
    }

    public String getHarvestDate() {
        return harvestDate;
    }

    public void setHarvestDate(String harvestDate) {
        this.harvestDate = harvestDate;
    }

    public Process getProcess() {
        return process;
    }

    public void setProcess(Process process) {
        this.process = process;
    }

    public Farms getFarm() {
        return farm;
    }

    public void setFarm(Farms farm) {
        this.farm = farm;
    }
}

