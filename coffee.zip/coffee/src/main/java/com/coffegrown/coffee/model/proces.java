package com.coffegrown.coffee.model;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table; // Opcional, pero recomendable

/*
 * Agregamos la anotación @Entity para que JPA reconozca esta clase como una entidad.
 * También usamos @Table para definir el nombre exacto de la tabla en la base de datos.
 */
@Entity
@Table(name="proces") // Se recomienda especificar el nombre de la tabla
public class proces { // Nombre de clase con mayúscula inicial

    @Id
    @Column(name="process_id") // Corregido el uso de @Column con mayúscula
    private int process_id;
    
    @Column(name="typ", length=100, nullable=false)
    private String typ;

    @Column(name="durationH", length=50, nullable=false)
    private String durationH;
    
    @Column(name="method", length=100, nullable=false)
    private String method;

    // Constructor vacío (necesario para JPA)
    public proces() {
    }

    // Constructor con parámetros
    public proces(int process_id, String typ, String durationH, String method) {
        this.process_id = process_id;
        this.typ = typ;
        this.durationH = durationH;
        this.method = method;
    }

    // Getters y Setters
    public int getProcess_id() {
        return process_id;
    }

    public void setProcess_id(int process_id) {
        this.process_id = process_id;
    }

    public String getTyp() {
        return typ;
    }

    public void setTyp(String typ) {
        this.typ = typ;
    }

    public String getDurationH() {
        return durationH;
    }

    public void setDurationH(String durationH) {
        this.durationH = durationH;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }
}

/* 
CREATE TABLE proces (
    process_id INT PRIMARY KEY,
    typ VARCHAR(100),
    durationH VARCHAR(50),
    method VARCHAR(100)
);
     */

