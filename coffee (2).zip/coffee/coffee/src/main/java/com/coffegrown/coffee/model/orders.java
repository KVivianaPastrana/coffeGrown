package com.coffegrown.coffee.model;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table; // Opcional, pero recomendable

import jakarta.persistence.ManyToOne;  // Importación añadida
import jakarta.persistence.JoinColumn;  // Importación añadida

@Entity
@Table(name="orders")
public class Orders {
    @Id
    @Column(name="order_id")
    private int order_id;
    
    @Column(name="order_date", length=50, nullable=false)
    private String order_date;

    @Column(name="quantityKg", length=50, nullable=false)
    private String quantityKg;

    @Column(name="price", length=50, nullable=false)
    private String price;                                               
    
    @Column(name="status", length=50, nullable=false)
    private String status;

    @ManyToOne
    @JoinColumn(name="coffee_id", referencedColumnName="coffee_id", nullable=false)
    private Coffe coffee;  // Corregido el nombre de la clase

    // Constructor vacío
    public Orders() {
    }

    // Constructor con parámetros
    public Orders(int order_id, String order_date, String quantityKg, String price, String status, Coffe coffee) {
        this.order_id = order_id;
        this.order_date = order_date;
        this.quantityKg = quantityKg;
        this.price = price;
        this.status = status;
        this.coffee = coffee;
    }

    // Getters y Setters
    public int getOrder_id() {
        return order_id;
    }

    public void setOrder_id(int order_id) {
        this.order_id = order_id;
    }

    public String getOrder_date() {
        return order_date;
    }

    public void setOrder_date(String order_date) {
        this.order_date = order_date;
    }

    public String getQuantityKg() {
        return quantityKg;
    }

    public void setQuantityKg(String quantityKg) {
        this.quantityKg = quantityKg;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Coffe getCoffee() {  // Corregido el nombre de la clase
        return coffee;
    }

    public void setCoffee(Coffe coffee) {  // Corregido el nombre de la clase
        this.coffee = coffee;
    }
}
