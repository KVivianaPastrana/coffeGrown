package com.coffegrown.coffee.model;

import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name="producer") // Se recomienda especificar el nombre de la tabla
public class producer { // Nombre de clase con mayúscula inicial

    @Id
    @Column(name="producer_id") // Corregido el uso de @Column con mayúscula
    private int producer_id;
    
    @Column(name="producerName", length=100, nullable=false)
    private String producerName;

    @Column(name="certification", length=100, nullable=false)
    private String certification;

    @Column(name="contact", length=50, nullable=false)
    private String contact;

    @ManyToOne
    @JoinColumn(name="farm_id", referencedColumnName="farm_id", nullable=false)
    private Farms farm;

    // Constructor vacío (necesario para JPA)
    public producer() {
    }

    // Constructor con parámetros
    public producer(int producer_id, String producerName, String certification, String contact, Farms farm) {
        this.producer_id = producer_id;
        this.producerName = producerName;
        this.certification = certification;
        this.contact = contact;
        this.farm = farm;
    }

    // Getters y Setters
    public int getProducer_id() {
        return producer_id;
    }                                               

    public void setProducer_id(int producer_id) {
        this.producer_id = producer_id;
    }

    public String getProducerName() {
        return producerName;
    }

    public void setProducerName(String producerName) {
        this.producerName = producerName;
    }                                               

    public String getCertification() {
        return certification;
    }

    public void setCertification(String certification) {
        this.certification = certification;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public Farms getFarm() {
        return farm;
    }

    public void setFarm(Farms farm) {
        this.farm = farm;
    }
}                                           


/*
 * Columns:
producer_id int(11) PK 
producerName varchar(100) 
certification varchar(100) 
contact int(11) 
farm_id int(11)
 */