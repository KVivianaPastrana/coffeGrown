package com.coffegrown.coffee.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table; // Opcional, pero recomendable

@Entity
@Table(name="farm") // Se recomienda especificar el nombre de la tabla      
public class Farms { // Nombre de clase con mayúscula inicial        

    @Id                                                 
    @Column(name="farm_id") // Corregido el uso de @Column con mayúscula
    private int farm_id;
    
    @Column(name="farmName", length=100, nullable=false)
    private String farmName;

    @Column(name="location", length=50, nullable=false)
    private String location;

    @Column(name="altitude", length=50, nullable=false)
    private String altitude;

    @Column(name="sizeH", length=50, nullable=false)
    private String sizeH;

    // Constructor vacío (necesario para JPA)
    public Farms() {
    }

    // Constructor con parámetros
    public Farms(int farm_id, String farmName, String location, String altitude, String sizeH) {
        this.farm_id = farm_id;
        this.farmName = farmName;
        this.location = location;
        this.altitude = altitude;
        this.sizeH = sizeH;
    }                                               

    // Getters y Setters
    public int getFarm_id() {
        return farm_id;
    }

    public void setFarm_id(int farm_id) {
        this.farm_id = farm_id;
    }                                               

    public String getFarmName() {
        return farmName;
    }

    public void setFarmName(String farmName) {
        this.farmName = farmName;
    }

    public String getLocation() {
        return location;
    }                                               

    public void setLocation(String location) {                                               
        this.location = location;
    }

    public String getAltitude() {
        return altitude;
    }

    public void setAltitude(String altitude) {
        this.altitude = altitude;
    }

    public String getSizeH() {
        return sizeH;
    }                                               

    public void setSizeH(String sizeH) {
        this.sizeH = sizeH;
    }
}                                   

/*
Columns:
farm_id int(11) PK 
farmName varchar(100) 
location int(11) 
altitude int(11) 
sizeH int(11)
 */
