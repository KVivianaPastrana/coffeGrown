

package com.coffegrown.coffee.model;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table; // Opcional, pero recomendable

import jakarta.persistence.*;


@Entity
@Table(name="distributor") // Nombre de la tabla en la base de datos
public class distributorCoffee {  

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // ID autoincrementable
    @Column(name="distributor_id")
    private int id;

    @ManyToOne
    @JoinColumn(name="transportId", nullable=false) // Clave foránea a Transport
    private transportCoffee transport;

    @ManyToOne
    @JoinColumn(name="coffeId", nullable=false) // Clave foránea a Coffee
    private CoffeeProduct coffee;

    @Column(name="distributorName", length=100, nullable=false)
    private String distributorName;

    @Column(name="distributor_zone", length=100, nullable=false)
    private String distributorZone;

    @Column(name="contact", length=20, nullable=false)
    private String contact;

    // Constructor vacío (requerido por JPA)
    public distributorCoffee() {
    }

    // Constructor con parámetros sin incluir el ID (autogenerado)
    public distributorCoffee(transportCoffee transport , CoffeeProduct coffee, String distributorName, String distributorZone, String contact) {
        this.transport = transport;
        this.coffee = coffee;
        this.distributorName = distributorName;
        this.distributorZone = distributorZone;
        this.contact = contact;
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public transportCoffee getTransport() {
        return transport;
    }

    public void setTransport(transportCoffee transport) {
        this.transport = transport;
    }

    public CoffeeProduct getCoffee() {
        return coffee;
    }

    public void setCoffee(CoffeeProduct coffee) {
        this.coffee = coffee;
    }

    public String getDistributorName() {
        return distributorName;
    }

    public void setDistributorName(String distributorName) {
        this.distributorName = distributorName;
    }

    public String getDistributorZone() {
        return distributorZone;
    }

    public void setDistributorZone(String distributorZone) {
        this.distributorZone = distributorZone;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }
}


/*
Create table distributor (
    distributor_id INT PRIMARY KEY,
    coffeId INT NOT NULL,
    transportId INT NOT NULL,
    distributorName VARCHAR(100) not null,
    distributor_zone VARCHAR(100) not null,
    contact VARCHAR(20) not null
);
 */