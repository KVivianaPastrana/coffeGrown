package com.coffegrown.coffee.DTO;

public class CoffeeOrderDTO {

    private int orderId;
    private int coffeeId;

    // Constructor vacío (para frameworks como Jackson)
    public CoffeeOrderDTO() {
    }

    // Constructor con parámetros
    public CoffeeOrderDTO(int orderId, int coffeeId) {
        this.orderId = orderId;
        this.coffeeId = coffeeId;
    }

    // Getters y Setters
    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getCoffeeId() {
        return coffeeId;
    }

    public void setCoffeeId(int coffeeId) {
        this.coffeeId = coffeeId;
    }
}
