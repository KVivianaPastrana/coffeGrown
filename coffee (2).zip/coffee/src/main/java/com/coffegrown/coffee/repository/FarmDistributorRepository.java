package com.coffegrown.coffee.repository;

import com.coffegrown.coffee.model.DistributorFarmId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FarmDistributorRepository extends JpaRepository<DistributorFarmId, Long> {
    // Métodos personalizados pueden agregarse si es necesario
}
