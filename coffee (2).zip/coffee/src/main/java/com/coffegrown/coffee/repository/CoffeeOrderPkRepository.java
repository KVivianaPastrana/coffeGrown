package com.coffegrown.coffee.repository;

import com.coffegrown.coffee.model.OrderCoffee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CoffeeOrderPkRepository extends JpaRepository<OrderCoffee, Integer> { 
    // Métodos personalizados pueden agregarse si es necesario
}