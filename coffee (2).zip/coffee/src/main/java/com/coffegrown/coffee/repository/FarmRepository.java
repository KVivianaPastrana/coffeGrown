package com.coffegrown.coffee.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.coffegrown.coffee.model.Farms;

@Repository // Asegúrate de que esta anotación esté presente
public interface FarmRepository extends JpaRepository<Farms, Integer> {
    // Métodos adicionales si es necesario
}

/*
 * package com.sena.crud_basic.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sena.crud_basic.model.user;

public interface Iuser extends JpaRepository
<user,Integer>
{

    /*
     * C
     * R
     * U
     * D
     */

 