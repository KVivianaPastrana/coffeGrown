package com.coffegrown.coffee.controller;

import com.coffegrown.coffee.model.CoffeeProducers;
import com.coffegrown.coffee.servise.CoffeeProducerService;
import com.coffegrown.coffee.DTO.CoffeeProducerDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import com.coffegrown.coffee.model.Farms; // IMPORTACIÓN NECESARIA

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/producers")   // Ruta del controlador
public class CoffeeProducerController {

    @Autowired
    private CoffeeProducerService CoffeeProducerService;

    // POST (REGISTER)
    @PostMapping
    public ResponseEntity<Object> registerCoffeeProducer(@RequestBody CoffeeProducerDTO coffeeProducerDTO) {
        CoffeeProducers coffeeProducer = new CoffeeProducers();
        coffeeProducer.setProducerName(coffeeProducerDTO.getProducerName());
        coffeeProducer.setCertification(coffeeProducerDTO.getCertification());
        coffeeProducer.setPassword(coffeeProducerDTO.getPassword());
        coffeeProducer.setContact(coffeeProducerDTO.getContact());

        // Aquí deberías mapear el farmId, puedes usar un servicio para obtener el objeto Farm relacionado
        // Ejemplo: Farm farm = farmService.findById(coffeeProducerDTO.getFarmId());
        coffeeProducer.setFarm(new Farms()); // Deberás reemplazar con la lógica adecuada para obtener el Farm

        CoffeeProducerService.save(coffeeProducerDTO); // Llama al servicio para guardar el productor de café

        return new ResponseEntity<>("Coffee producer registered successfully", HttpStatus.OK);
    }
}
