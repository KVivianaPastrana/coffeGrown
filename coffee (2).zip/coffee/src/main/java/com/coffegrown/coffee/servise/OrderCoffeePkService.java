package com.coffegrown.coffee.servise;


import com.coffegrown.coffee.model.OrderCoffee;
import com.coffegrown.coffee.repository.CoffeeOrderPkRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderCoffeePkService {

    private final CoffeeOrderPkRepository orderCoffeeRepository;

    // Inyección de dependencias mediante el constructor (recomendado)
    @Autowired
    public OrderCoffeePkService(CoffeeOrderPkRepository orderCoffeeRepository) {
        this.orderCoffeeRepository = orderCoffeeRepository;
    }

    // Obtener todas las órdenes
    public List<OrderCoffee> getAllOrders() {
        return orderCoffeeRepository.findAll();
    }

    // Obtener una orden por ID
    public Optional<OrderCoffee> getOrderById(int id) {
        return orderCoffeeRepository.findById(id);
    }

    // Crear una nueva orden
    public OrderCoffee createOrder(OrderCoffee orderCoffee) {
        return orderCoffeeRepository.save(orderCoffee);
    }

    // Actualizar una orden existente
    public OrderCoffee updateOrder(int id, OrderCoffee updatedOrder) {
        return orderCoffeeRepository.findById(id).map(existingOrder -> {
            existingOrder.setTransportId(updatedOrder.getTransportId());
            existingOrder.setOrder_date(updatedOrder.getOrder_date());
            existingOrder.setAmountKg(updatedOrder.getAmountKg());
            existingOrder.setPrice(updatedOrder.getPrice());
            existingOrder.setStatus(updatedOrder.getStatus());
            return orderCoffeeRepository.save(existingOrder);
        }).orElse(null);
    }

    // Eliminar una orden
    public boolean deleteOrder(int id) {
        if (orderCoffeeRepository.existsById(id)) {
            orderCoffeeRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
