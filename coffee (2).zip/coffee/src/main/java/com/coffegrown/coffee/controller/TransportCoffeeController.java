package com.coffegrown.coffee.controller;

import com.coffegrown.coffee.model.transportCoffee;
import com.coffegrown.coffee.servise.TransportCoffeeService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/transport") // Ruta base para los endpoints
public class TransportCoffeeController {

    private final TransportCoffeeService transportCoffeeService;

    public TransportCoffeeController(TransportCoffeeService transportCoffeeService) {
        this.transportCoffeeService = transportCoffeeService;
    }

    // Obtener todos los transportes
    @GetMapping
    public List<TransportCoffee> getAllTransport() {
        return transportCoffeeService.getAllTransport();
    }

    // Obtener un transporte por ID
    @GetMapping("/{id}")
    public ResponseEntity<TransportCoffee> getTransportById(@PathVariable int id) {
        Optional<TransportCoffee> transport = transportCoffeeService.getTransportById(id);
        return transport.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    // Crear un nuevo transporte
    @PostMapping
    public ResponseEntity<TransportCoffee> createTransport(@RequestBody TransportCoffee transportCoffee) {
        TransportCoffee newTransport = transportCoffeeService.createTransport(transportCoffee);
        return ResponseEntity.ok(newTransport);
    }

    // Actualizar un transporte existente
    @PutMapping("/{id}")
    public ResponseEntity<TransportCoffee> updateTransport(@PathVariable int id, @RequestBody TransportCoffee transportCoffee) {
        Optional<TransportCoffee> updatedTransport = transportCoffeeService.updateTransport(id, transportCoffee);
        return updatedTransport.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    // Eliminar un transporte
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTransport(@PathVariable int id) {
        boolean deleted = transportCoffeeService.deleteTransport(id);
        if (deleted) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
