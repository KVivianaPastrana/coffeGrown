package com.coffegrown.coffee.controller;

import com.coffegrown.coffee.model.OrderCoffee;
import com.coffegrown.coffee.servise.OrderCoffeePkService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/coffee-orders") // Ruta base para los pedidos de café
public class CoffeeOrderPkController { 
    
    public class OrderCoffeePkController {
    
        @Autowired
        private OrderCoffeePkService orderCoffeeService;
    
        // Obtener todas las órdenes
        @GetMapping
        public List<OrderCoffee> getAllOrders() {
            return orderCoffeeService.getAllOrders();
        }
    
        // Obtener una orden por ID
        @GetMapping("/{id}")
        public ResponseEntity<OrderCoffee> getOrderById(@PathVariable int id) {
            Optional<OrderCoffee> order = orderCoffeeService.getOrderById(id);
            return order.map(ResponseEntity::ok)
                        .orElseGet(() -> ResponseEntity.notFound().build());
        }
    
        // Crear una nueva orden
        @PostMapping
        public OrderCoffee createOrder(@RequestBody OrderCoffee orderCoffee) {
            return orderCoffeeService.createOrder(orderCoffee);
        }
    
        // Actualizar una orden
        @PutMapping("/{id}")
        public ResponseEntity<OrderCoffee> updateOrder(@PathVariable int id, @RequestBody OrderCoffee orderCoffee) {
            OrderCoffee updatedOrder = orderCoffeeService.updateOrder(id, orderCoffee);
            return updatedOrder != null ? ResponseEntity.ok(updatedOrder) : ResponseEntity.notFound().build();
        }
    
        // Eliminar una orden
        @DeleteMapping("/{id}")
        public ResponseEntity<Void> deleteOrder(@PathVariable int id) {
            boolean deleted = orderCoffeeService.deleteOrder(id);
            return deleted ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
        }
    }
    
}