package com.coffegrown.coffee.DTO;

public class DistributorFarmDTO {
    private Long id;
    private Long farmId;
    private Long distributorId;

    // Constructor vacío
    public DistributorFarmDTO() {
    }

    // Constructor con parámetros
    public DistributorFarmDTO(Long id, Long farmId, Long distributorId) {
        this.id = id;
        this.farmId = farmId;
        this.distributorId = distributorId;
    }

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getFarmId() {
        return farmId;
    }

    public void setFarmId(Long farmId) {
        this.farmId = farmId;
    }

    public Long getDistributorId() {
        return distributorId;
    }

    public void setDistributorId(Long distributorId) {
        this.distributorId = distributorId;
    }
}
