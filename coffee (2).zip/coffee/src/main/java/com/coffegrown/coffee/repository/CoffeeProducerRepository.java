package com.coffegrown.coffee.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.coffegrown.coffee.model.CoffeeProducers;

@Repository // Asegúrate de que esta anotación esté presente
public interface CoffeeProducerRepository extends JpaRepository<CoffeeProducers, Long> {
    // Métodos adicionales si es necesario
}