package com.coffegrown.coffee.model;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table; // Opcional, pero recomendable

@Entity
@Table(name="customer")
public class Customer { // Nombre de clase con mayúscula inicial
    @Id
    @Column(name="order_id")
    private int order_id;
    
    @Column(name="clientName", length=100, nullable=false)
    private String clientName;

    @Column(name="type", length=50, nullable=false)
    private String type;

    @Column(name="country", length=100, nullable=false)
    private String country;

    // Constructor vacío
    public Customer() {
    }

    // Constructor con parámetros
    public Customer(int order_id, String clientName, String type, String country) {
        this.order_id = order_id;
        this.clientName = clientName;
        this.type = type;
        this.country = country;
    }

    // Getters y Setters
    public int getOrder_id() {
        return order_id;
    }

    public void setOrder_id(int order_id) {
        this.order_id = order_id;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }   
}







/* 
CREATE TABLE Customer (
    orderId INT PRIMARY KEY,
    clientName VARCHAR(100),
    type VARCHAR(50),
    country VARCHAR(100)
);
     */

