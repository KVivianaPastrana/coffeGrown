package com.coffegrown.coffee.servise;

public package com.coffegrown.coffee.servise;

import com.coffegrown.coffee.model.CoffeeProduct;
import com.coffegrown.coffee.repository.CoffeeProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CoffeeProductService {

    private final CoffeeProductRepository coffeeProductRepository;

    @Autowired
    public CoffeeProductService(CoffeeProductRepository coffeeProductRepository) {
        this.coffeeProductRepository = coffeeProductRepository;
    }

    // Obtener todos los productos de café
    public List<CoffeeProduct> getAllCoffeeProducts() {
        return coffeeProductRepository.findAll();
    }

    // Obtener un producto de café por ID
    public Optional<CoffeeProduct> getCoffeeProductById(Long id) {
        return coffeeProductRepository.findById(id);
    }

    // Crear un nuevo producto de café
    public CoffeeProduct createCoffeeProduct(CoffeeProduct coffeeProduct) {
        return coffeeProductRepository.save(coffeeProduct);
    }

    // Actualizar un producto de café existente
    public CoffeeProduct updateCoffeeProduct(Long id, CoffeeProduct updatedCoffeeProduct) {
        return coffeeProductRepository.findById(id).map(existingProduct -> {
            existingProduct.setProcess(updatedCoffeeProduct.getProcess());
            existingProduct.setCoffeeType(updatedCoffeeProduct.getCoffeeType());
            existingProduct.setQuality(updatedCoffeeProduct.getQuality());
            existingProduct.setVariety(updatedCoffeeProduct.getVariety());
            existingProduct.setHarvestDate(updatedCoffeeProduct.getHarvestDate());
            existingProduct.setFoto(updatedCoffeeProduct.getFoto());
            return coffeeProductRepository.save(existingProduct);
        }).orElse(null);
    }

    // Eliminar un producto de café
    public boolean deleteCoffeeProduct(Long id) {
        if (coffeeProductRepository.existsById(id)) {
            coffeeProductRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
 {
    
}
