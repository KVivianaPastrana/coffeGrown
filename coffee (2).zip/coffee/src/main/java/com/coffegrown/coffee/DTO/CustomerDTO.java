package com.coffegrown.coffee.DTO;

public class CustomerDTO {

    private int orderId;
    private String clientName;
    private String type;
    private String country;

    // Constructor vacío
    public CustomerDTO() {}

    // Constructor con parámetros
    public CustomerDTO(int orderId, String clientName, String type, String country) {
        this.orderId = orderId;
        this.clientName = clientName;
        this.type = type;
        this.country = country;
    }

    // Getters y Setters
    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
}
