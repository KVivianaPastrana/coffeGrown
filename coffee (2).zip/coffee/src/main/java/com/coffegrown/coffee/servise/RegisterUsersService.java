package com.coffegrown.coffee.servise;

import com.coffegrown.coffee.DTO.RegisterUsersDTO;
import com.coffegrown.coffee.model.RegisterUsers;
import com.coffegrown.coffee.repository.RegisterUsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class RegisterUsersService {

    /*
     * save
     * findAll
     * findById
     * Delete
     */
    
    // Establecer conexión con el repositorio
    @Autowired
    private RegisterUsersRepository registerUsersRepository;

    // Registrar y actualizar usuario
    public void save(RegisterUsersDTO registerUsersDTO) {
        RegisterUsers userToSave = convertToModel(registerUsersDTO);
        registerUsersRepository.save(userToSave);
    }

    // Obtener todos los usuarios registrados
    public List<RegisterUsersDTO> findAll() {
        List<RegisterUsers> users = registerUsersRepository.findAll();
        return users.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    // Obtener usuario por id
    public RegisterUsersDTO findById(int id) {
        Optional<RegisterUsers> user = registerUsersRepository.findById(id);
        return user.map(this::convertToDTO).orElse(null);
    }

    // Eliminar usuario por id
    public void delete(int id) {
        registerUsersRepository.deleteById(id);
    }

    // Convertir DTO a Modelo
    public RegisterUsers convertToModel(RegisterUsersDTO registerUsersDTO) {
        RegisterUsers registerUser = new RegisterUsers();
        registerUser.setName(registerUsersDTO.getName());
        registerUser.setEmail(registerUsersDTO.getEmail());
        registerUser.setPassword(registerUsersDTO.getPassword());
        registerUser.setProducer(registerUsersDTO.getProducer());
        registerUser.setRegisterDate(registerUsersDTO.getRegisterDate());
        return registerUser;
    }

    // Convertir Modelo a DTO
    public RegisterUsersDTO convertToDTO(RegisterUsers registerUser) {
        RegisterUsersDTO registerUsersDTO = new RegisterUsersDTO(
                registerUser.getRegisterId(),
                registerUser.getName(),
                registerUser.getEmail(),
                registerUser.getPassword(),
                registerUser.getProducer(),
                registerUser.getRegisterDate()
        );
        return registerUsersDTO;
    }
}
