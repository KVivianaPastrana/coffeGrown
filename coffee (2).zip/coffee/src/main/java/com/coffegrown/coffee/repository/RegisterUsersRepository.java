package com.coffegrown.coffee.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.coffegrown.coffee.model.RegisterUsers;

public interface RegisterUsersRepository extends JpaRepository<RegisterUsers, Integer> {
    // Aquí puedes agregar métodos personalizados si lo necesitas
}
