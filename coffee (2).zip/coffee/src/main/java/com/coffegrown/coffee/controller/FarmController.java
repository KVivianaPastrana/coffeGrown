package com.coffegrown.coffee.controller;

import com.coffegrown.coffee.model.Farms;
import com.coffegrown.coffee.servise.FarmService;
import com.coffegrown.coffee.DTO.FarmDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController()
@RequestMapping("/api/farms")   
public class FarmController {
    
    
     @Autowired
     private FarmService farmService;
     
     // POST (REGISTER)
     @PostMapping

     public ResponseEntity<Object> registerFarm(@RequestBody FarmDTO farmDTO) {
        // Guardar la finca y obtener el objeto con el ID generado
        Farms farm = farmService.save(farmDTO);
        return new ResponseEntity<>("Farm registered successfully with ID: " + farm.getFarm_id(), HttpStatus.OK);

     }
    }

/*
 * package com.sena.crud_basic.controller;

import org.springframework.web.bind.annotation.RestController;

import com.sena.crud_basic.DTO.userDTO;
import com.sena.crud_basic.service.userService;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@RestController
@RequestMapping("/api/v1/user")
public class userController {

    /*
     * GET
     * POST(REGISTER)
     * PUT
     * DELETE
     
    @Autowired
    private userService userService;

    @PostMapping("/")
    public ResponseEntity<Object> registerUser(@RequestBody userDTO user) {
        userService.save(user);
        return new ResponseEntity<>("register OK", HttpStatus.OK);
    }

}
 */