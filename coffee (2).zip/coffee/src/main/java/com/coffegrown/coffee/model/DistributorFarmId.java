// Archivo: DistributorFarm.java (tabla pivote)
package com.coffegrown.coffee.model;

import jakarta.persistence.*;

@Entity
@Table(name="distributor_farm") // Nombre más simple y siguiendo convenciones
public class DistributorFarmId {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id")
    private Long id;
    
    @ManyToOne
    @JoinColumn(name="farm_id", nullable=false)
    private Farms farm;
    
    @ManyToOne
    @JoinColumn(name="distributor_id", nullable=false)
    private distributorCoffee distributor;
    
    // Constructor vacío (requerido por JPA)
    public DistributorFarmId() {
    }
    
    // Constructor con parámetros
    public DistributorFarmId(Farms farm, distributorCoffee distributor) {
        this.farm = farm;
        this.distributor = distributor;
    }
    
    // Getters y Setters
    public Long getId() {
        return id;
    }
    
    public Farms getFarm() {
        return farm;
    }
    
    public void setFarm(Farms farm) {
        this.farm = farm;
    }
    
    public distributorCoffee getDistributor() {
        return distributor;
    }
    
    public void setDistributor(distributorCoffee distributor) {
        this.distributor = distributor;
    }
}