package com.coffegrown.coffee.DTO;


public class DistributorCoffeeDTO {
    private int id;
    private int transportId;
    private int coffeeId;
    private String distributorName;
    private String distributorZone;
    private String contact;

    // Constructor vacío
    public DistributorCoffeeDTO() {
    }

    // Constructor con parámetros
    public DistributorCoffeeDTO(int id, int transportId, int coffeeId, String distributorName, String distributorZone, String contact) {
        this.id = id;
        this.transportId = transportId;
        this.coffeeId = coffeeId;
        this.distributorName = distributorName;
        this.distributorZone = distributorZone;
        this.contact = contact;
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getTransportId() {
        return transportId;
    }

    public void setTransportId(int transportId) {
        this.transportId = transportId;
    }

    public int getCoffeeId() {
        return coffeeId;
    }

    public void setCoffeeId(int coffeeId) {
        this.coffeeId = coffeeId;
    }

    public String getDistributorName() {
        return distributorName;
    }

    public void setDistributorName(String distributorName) {
        this.distributorName = distributorName;
    }

    public String getDistributorZone() {
        return distributorZone;
    }

    public void setDistributorZone(String distributorZone) {
        this.distributorZone = distributorZone;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }
}
 
