package com.coffegrown.coffee.model;

import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.CascadeType;
@Entity
@Table(name="producer_coffee") // Se recomienda especificar el nombre de la tabla
public class CoffeeProducers { // Nombre de clase con mayúscula inicial

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="producer_id") // Corregido el uso de @Column con mayúscula
    private  Long  producerId;
    
    @Column(name="producer_name", length=100, nullable=false)
    private String producerName;

    @Column(name="certification", length=100, nullable=false)
    private String certification;

    @Column(name="password", length=50, nullable=false)
    private String password;

    @Column(name="contact", length=50, nullable=false)
    private String contact;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="farm_id", referencedColumnName="farm_id", nullable=false)
    private Farms farm;
    // Constructor vacío (necesario para JPA)
    public CoffeeProducers() {
    }

    // Constructor con parámetros
    public CoffeeProducers(Long producerId, String producerName, String certification,String password , String contact, Farms farm) {
        this.producerId = producerId;
        this.producerName = producerName;
        this.certification = certification;
        this.password = password;
        this.contact = contact;
        this.farm = farm;
    }

    // Getters y Setters
    public Long getProducerId() {
        return producerId;
    }                                               

    public void setProducerId(Long producerId) {
        this.producerId = producerId;
    }

    public String getProducerName() {
        return producerName;
    }

    public void setProducerName(String producerName) {
        this.producerName = producerName;
    }                                               

    public String getCertification() {
        return certification;
    }

    public void setCertification(String certification) {
        this.certification = certification;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public Farms getFarm() {
        return farm;
    }

    public void setFarm(Farms farm) {
        this.farm = farm;
    }
}                                           


/*
 * Columns:
producer_id int(11) PK 
producerName varchar(100) 
certification varchar(100) 
contact int(11) 
farm_id int(11)
 */