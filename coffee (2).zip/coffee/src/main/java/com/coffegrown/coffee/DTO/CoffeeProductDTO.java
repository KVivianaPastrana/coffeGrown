package com.coffegrown.coffee.DTO;

import com.coffegrown.coffee.model.CoffeeProcess;

public class CoffeeProductDTO {

    private Long coffeeId;
    private CoffeeProcess process;
    private String coffeeType;
    private String quality;
    private String variety;
    private String harvestDate;
    private String foto;

    // Constructor vacío
    public CoffeeProductDTO() {}

    // Constructor con parámetros
    public CoffeeProductDTO(Long coffeeId, CoffeeProcess process, String coffeeType, String quality, String variety, String harvestDate, String foto) {
        this.coffeeId = coffeeId;
        this.process = process;
        this.coffeeType = coffeeType;
        this.quality = quality;
        this.variety = variety;
        this.harvestDate = harvestDate;
        this.foto = foto;
    }

    // Getters y Setters
    public Long getCoffeeId() {
        return coffeeId;
    }

    public void setCoffeeId(Long coffeeId) {
        this.coffeeId = coffeeId;
    }

    public CoffeeProcess getProcess() {
        return process;
    }

    public void setProcess(CoffeeProcess process) {
        this.process = process;
    }

    public String getCoffeeType() {
        return coffeeType;
    }

    public void setCoffeeType(String coffeeType) {
        this.coffeeType = coffeeType;
    }

    public String getQuality() {
        return quality;
    }

    public void setQuality(String quality) {
        this.quality = quality;
    }

    public String getVariety() {
        return variety;
    }

    public void setVariety(String variety) {
        this.variety = variety;
    }

    public String getHarvestDate() {
        return harvestDate;
    }

    public void setHarvestDate(String harvestDate) {
        this.harvestDate = harvestDate;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }
}
