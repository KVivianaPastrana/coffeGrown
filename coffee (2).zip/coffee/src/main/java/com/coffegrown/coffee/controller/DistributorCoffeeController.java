package com.coffegrown.coffee.controller;

import com.coffegrown.coffee.model.distributorCoffee;
import com.coffegrown.coffee.servise.DistributorCoffeeService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/distributors") // Ruta base para los endpoints
public class DistributorCoffeeController {

    private final DistributorCoffeeService distributorCoffeeService;

    public DistributorCoffeeController(DistributorCoffeeService distributorCoffeeService) {
        this.distributorCoffeeService = distributorCoffeeService;
    }

    // Obtener todos los distribuidores
    @GetMapping
    public List<distributorCoffee> getAllDistributors() {
        return distributorCoffeeService.getAllDistributors();
    }

    // Obtener un distribuidor por ID
    @GetMapping("/{id}")
    public ResponseEntity<distributorCoffee> getDistributorById(@PathVariable int id) {
        Optional<distributorCoffee> distributor = distributorCoffeeService.getDistributorById(id);
        return distributor.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    // Crear un nuevo distribuidor
    @PostMapping
    public ResponseEntity<distributorCoffee> createDistributor(@RequestBody distributorCoffee distributorCoffee) {
        distributorCoffee newDistributor = distributorCoffeeService.createDistributor(distributorCoffee);
        return ResponseEntity.ok(newDistributor);
    }

    // Actualizar un distribuidor existente
    @PutMapping("/{id}")
    public ResponseEntity<distributorCoffee> updateDistributor(@PathVariable int id, @RequestBody DistributorCoffee distributorCoffee) {
        Optional<distributorCoffee> updatedDistributor = distributorCoffeeService.updateDistributor(id, distributorCoffee);
        return updatedDistributor.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    // Eliminar un distribuidor
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDistributor(@PathVariable int id) {
        boolean deleted = distributorCoffeeService.deleteDistributor(id);
        if (deleted) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
