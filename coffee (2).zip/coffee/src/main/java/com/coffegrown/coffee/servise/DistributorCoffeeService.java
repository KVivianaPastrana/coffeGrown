package com.coffegrown.coffee.servise;

import com.coffegrown.coffee.model.distributorCoffee;
import com.coffegrown.coffee.repository.DistributorCoffeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DistributorCoffeeService {

    private final DistributorCoffeeRepository distributorCoffeeRepository;

    @Autowired
    public DistributorCoffeeService(DistributorCoffeeRepository distributorCoffeeRepository) {
        this.distributorCoffeeRepository = distributorCoffeeRepository;
    }

    // Obtener todos los distribuidores
    public List<distributorCoffee> getAllDistributors() {
        return distributorCoffeeRepository.findAll();
    }

    // Obtener un distribuidor por ID
    public Optional<distributorCoffee> getDistributorById(int id) {
        return distributorCoffeeRepository.findById(id);
    }

    // Crear un nuevo distribuidor
    public distributorCoffee createDistributor(distributorCoffee distributorCoffee) {
        return distributorCoffeeRepository.save(distributorCoffee);
    }

    // Actualizar un distribuidor existente
    public Optional<distributorCoffee> updateDistributor(int id, distributorCoffee distributorCoffee) {
        return distributorCoffeeRepository.findById(id).map(existingDistributor -> {
            existingDistributor.setName(distributorCoffee.getName());
            existingDistributor.setLocation(distributorCoffee.getLocation());
            existingDistributor.setPhone(distributorCoffee.getPhone());
            return distributorCoffeeRepository.save(existingDistributor);
        });
    }

    // Eliminar un distribuidor
    public boolean deleteDistributor(int id) {
        if (distributorCoffeeRepository.existsById(id)) {
            distributorCoffeeRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
