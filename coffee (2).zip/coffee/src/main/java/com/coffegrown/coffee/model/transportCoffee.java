package com.coffegrown.coffee.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class transportCoffee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="transportId")
    private int transportId;
    
    @Column(name="vehicleType",length=100,nullable=false)
    private String vehicleType;
    
    @Column(name="vehicleNumber",length=50,nullable=false)    
    private String vehicleNumber;
    
    @Column(name="estimatedTime",length=50,nullable=false)
    private String estimatedTime;
    public transportCoffee() {
    }

    public transportCoffee (int transportId, String vehicleType, String vehicleNumber, String estimatedTime) {
        this.transportId = transportId;
        this.vehicleType = vehicleType;
        this.vehicleNumber = vehicleNumber;
        this.estimatedTime = estimatedTime;
    }

    public int getTransportId() {
        return transportId;
    }

    public void setTransportId(int transportId) {
        this.transportId = transportId;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getVehicleNumber() {
        return vehicleNumber;
    }

    public void setVehicleNumber(String vehicleNumber) {
        this.vehicleNumber = vehicleNumber;
    }


}