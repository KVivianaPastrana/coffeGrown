package com.coffegrown.coffee.controller;

import com.coffegrown.coffee.model.CoffeeProduct;
import com.coffegrown.coffee.servise.CoffeeProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/coffee") // Ruta base del controlador
public class CoffeeProductController {

    @Autowired
    private CoffeeProductService coffeeProductService;

    // Obtener todos los productos de café
    @GetMapping
    public List<CoffeeProduct> getAllCoffeeProducts() {
        return coffeeProductService.getAllCoffeeProducts();
    }

    // Obtener un producto de café por ID
    @GetMapping("/{id}")
    public ResponseEntity<CoffeeProduct> getCoffeeProductById(@PathVariable Long id) {
        Optional<CoffeeProduct> coffeeProduct = coffeeProductService.getCoffeeProductById(id);
        return coffeeProduct.map(ResponseEntity::ok)
                            .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Crear un nuevo producto de café
    @PostMapping
    public CoffeeProduct createCoffeeProduct(@RequestBody CoffeeProduct coffeeProduct) {
        return coffeeProductService.saveCoffeeProduct(coffeeProduct);
    }

    // Actualizar un producto de café
    @PutMapping("/{id}")
    public ResponseEntity<CoffeeProduct> updateCoffeeProduct(@PathVariable Long id, 
                                                             @RequestBody CoffeeProduct coffeeProduct) {
        CoffeeProduct updatedProduct = coffeeProductService.updateCoffeeProduct(id, coffeeProduct);
        return ResponseEntity.ok(updatedProduct);
    }

    // Eliminar un producto de café
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCoffeeProduct(@PathVariable Long id) {
        coffeeProductService.deleteCoffeeProduct(id);
        return ResponseEntity.noContent().build();
    }
}
