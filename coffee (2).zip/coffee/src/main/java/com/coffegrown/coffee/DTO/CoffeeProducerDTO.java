package com.coffegrown.coffee.DTO;

import com.coffegrown.coffee.model.Farms;

public class CoffeeProducerDTO {

    private String producerName;
    private String certification;
    private String password;
    private String contact;
    private Farms farm; // Campo farm añadido

    // Constructor vacío
    public CoffeeProducerDTO() {}

    // Constructor con parámetros
    public CoffeeProducerDTO(String producerName, String certification, String password, String contact, Farms farm) {
        this.producerName = producerName;
        this.certification = certification;
        this.password = password;
        this.contact = contact;
        this.farm = farm; // Inicializar el campo farm
    }

    // Getters y Setters
    public String getProducerName() {
        return producerName;
    }

    public void setProducerName(String producerName) {
        this.producerName = producerName;
    }

    public String getCertification() {
        return certification;
    }

    public void setCertification(String certification) {
        this.certification = certification;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public Farms getFarm() {
        return farm; // Getter para farm
    }

    public void setFarm(Farms farm) {
        this.farm = farm; // Setter para farm
    }
}
