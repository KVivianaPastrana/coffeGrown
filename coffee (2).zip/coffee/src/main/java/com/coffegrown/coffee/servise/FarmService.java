package com.coffegrown.coffee.servise;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coffegrown.coffee.DTO.FarmDTO;
import com.coffegrown.coffee.model.Farms;
import com.coffegrown.coffee.repository.FarmRepository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class FarmService {

    /*
     * save
     * findAll
     * findById
     * Delete
     */
    
    /* establish connection with the repository */
    @Autowired
    private FarmRepository farmRepository; // Suponiendo que tienes un repositorio

    public void save(Farms farm) {
        if (farm.getFarm_id() != null) {
            farmRepository.save(farm); // Si el ID no es nulo, usa save (merge)
        } else {
            farmRepository.save(farm); // Si es nuevo, también usa save (persist)
        }
    }
    // register and update
    public Farms save(FarmDTO farmDTO) {
        Farms farm = new Farms();
        farm.setFarmName(farmDTO.getFarmName());
        farm.setLocation(farmDTO.getLocation());
        farm.setAltitude(farmDTO.getAltitude());
        farm.setSizeH(farmDTO.getSizeH());
        
        return farmRepository.save(farm);
    }
    
    // get all farms
    public List<FarmDTO> findAll() {
        List<Farms> farms = farmRepository.findAll();
        return farms.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }
    
    // get farm by id
    public FarmDTO findById(Integer id) {
        Optional<Farms> farm = farmRepository.findById(id);
        return farm.map(this::convertToDTO).orElse(null);
    }
    
    // delete farm
    public void delete(Integer id) {
        farmRepository.deleteById(id);
    }

    // Convert DTO to Model
    public Farms convertToModel(FarmDTO farmDTO) {
        Farms farm = new Farms();
        farm.setFarmName(farmDTO.getFarmName());
        farm.setLocation(farmDTO.getLocation());
        farm.setAltitude(farmDTO.getAltitude());
        farm.setSizeH(farmDTO.getSizeH());
        return farm;
    }

    // Convert Model to DTO
    public FarmDTO convertToDTO(Farms farm) {
        FarmDTO farmDTO = new FarmDTO(
                farm.getFarmName(),
                farm.getLocation(),
                farm.getAltitude(),
                farm.getSizeH()
        );
        return farmDTO;
    }
}