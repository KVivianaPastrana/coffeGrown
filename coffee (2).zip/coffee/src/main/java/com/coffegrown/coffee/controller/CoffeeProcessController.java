package com.coffegrown.coffee.controller;

import com.coffegrown.coffee.model.CoffeeProcess;
import com.coffegrown.coffee.servise.CoffeeProcessService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/processes") // Ruta base del controlador
public class CoffeeProcessController {

    @Autowired
    private CoffeeProcessService coffeeProcessService;

    // Obtener todos los procesos
    @GetMapping
    public ResponseEntity<List<CoffeeProcess>> getAllProcesses() {
        List<CoffeeProcess> processes = coffeeProcessService.getAllProcesses();
        return new ResponseEntity<>(processes, HttpStatus.OK);
    }

    // Obtener un proceso por ID
    @GetMapping("/{id}")
    public ResponseEntity<Object> getProcessById(@PathVariable int id) {
        Optional<CoffeeProcess> process = coffeeProcessService.getProcessById(id);
        if (process.isPresent()) {
            return new ResponseEntity<>(process.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Process not found", HttpStatus.NOT_FOUND);
        }
    }

    // Registrar un nuevo proceso
    @PostMapping
    public ResponseEntity<Object> createProcess(@RequestBody CoffeeProcess coffeeProcess) {
        CoffeeProcess savedProcess = coffeeProcessService.saveProcess(coffeeProcess);
        return new ResponseEntity<>(savedProcess, HttpStatus.CREATED);
    }

    // Actualizar un proceso existente
    @PutMapping("/{id}")
    public ResponseEntity<Object> updateProcess(@PathVariable int id, @RequestBody CoffeeProcess updatedProcess) {
        CoffeeProcess process = coffeeProcessService.updateProcess(id, updatedProcess);
        if (process != null) {
            return new ResponseEntity<>(process, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Process not found", HttpStatus.NOT_FOUND);
        }
    }

    // Eliminar un proceso por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Object> deleteProcess(@PathVariable int id) {
        boolean deleted = coffeeProcessService.deleteProcess(id);
        if (deleted) {
            return new ResponseEntity<>("Process deleted successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Process not found", HttpStatus.NOT_FOUND);
        }
    }
}
