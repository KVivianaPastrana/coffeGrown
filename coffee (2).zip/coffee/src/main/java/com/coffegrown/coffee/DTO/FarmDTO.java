package com.coffegrown.coffee.DTO;

public class FarmDTO {
    private String farmName;
    private String location;
    private Integer altitude;
    private Integer sizeH;
    
    // Constructores
    public FarmDTO() {}
    
    public FarmDTO(String farmName, String location, Integer altitude, Integer sizeH) {
        this.farmName = farmName;
        this.location = location;
        this.altitude = altitude;
        this.sizeH = sizeH;
    }
    
    // Getters y Setters
    public String getFarmName() {
        return farmName;
    }
    
    public void setFarmName(String farmName) {
        this.farmName = farmName;
    }
    
    public String getLocation() {
        return location;
    }
    
    public void setLocation(String location) {
        this.location = location;
    }
    
    public Integer getAltitude() {
        return altitude;
    }
    
    public void setAltitude(Integer altitude) {
        this.altitude = altitude;
    }
    
    public Integer getSizeH() {
        return sizeH;
    }
    
    public void setSizeH(Integer sizeH) {
        this.sizeH = sizeH;
    }
}