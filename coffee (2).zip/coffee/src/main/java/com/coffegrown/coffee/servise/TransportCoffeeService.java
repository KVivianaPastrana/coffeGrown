package com.coffegrown.coffee.servise;

import com.coffegrown.coffee.model.transportCoffee;
import com.coffegrown.coffee.repository.TransportCoffeeRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TransportCoffeeService {

    private final TransportCoffeeRepository transportCoffeeRepository;

    
    public TransportCoffeeService(TransportCoffeeRepository transportCoffeeRepository) {
        this.transportCoffeeRepository = transportCoffeeRepository;
    }

    // Obtener todos los transportes
    public List<transportCoffee> getAllTransport() {
        return transportCoffeeRepository.findAll();
    }

    // Obtener un transporte por ID
    public Optional<transportCoffee> getTransportById(int id) {
        return transportCoffeeRepository.findById(id);
    }

    // Crear un nuevo transporte
    public transportCoffee createTransport(transportCoffee transportCoffee) {
        return transportCoffeeRepository.save(transportCoffee);
    }

    // Actualizar un transporte existente
    public Optional<transportCoffee> updateTransport(int id, transportCoffee transportCoffee) {
        if (transportCoffeeRepository.existsById(id)) {
            transportCoffee.setTransportId(id); // Asegurar que se mantiene el mismo ID
            return Optional.of(transportCoffeeRepository.save(transportCoffee));
        }
        return Optional.empty();
    }

    // Eliminar un transporte
    public boolean deleteTransport(int id) {
        if (transportCoffeeRepository.existsById(id)) {
            transportCoffeeRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
