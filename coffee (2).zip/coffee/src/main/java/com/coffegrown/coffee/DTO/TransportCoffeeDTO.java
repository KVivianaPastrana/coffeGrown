package com.coffegrown.coffee.DTO;

public class TransportCoffeeDTO {
    private int transportId;
    private String vehicleType;
    private String vehicleNumber;
    private String estimatedTime;

    // Constructor vacío
    public TransportCoffeeDTO() {
    }

    // Constructor con parámetros
    public TransportCoffeeDTO(int transportId, String vehicleType, String vehicleNumber, String estimatedTime) {
        this.transportId = transportId;
        this.vehicleType = vehicleType;
        this.vehicleNumber = vehicleNumber;
        this.estimatedTime = estimatedTime;
    }

    // Getters y Setters
    public int getTransportId() {
        return transportId;
    }

    public void setTransportId(int transportId) {
        this.transportId = transportId;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getVehicleNumber() {
        return vehicleNumber;
    }

    public void setVehicleNumber(String vehicleNumber) {
        this.vehicleNumber = vehicleNumber;
    }

    public String getEstimatedTime() {
        return estimatedTime;
    }

    public void setEstimatedTime(String estimatedTime) {
        this.estimatedTime = estimatedTime;
    }
}
