package com.coffegrown.coffee.servise;

import com.coffegrown.coffee.model.DistributorFarmId;
import com.coffegrown.coffee.repository.FarmDistributorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DistributorFarmService {

    private final FarmDistributorRepository distributorFarmRepository;

    @Autowired
    public DistributorFarmService(FarmDistributorRepository distributorFarmRepository) {
        this.distributorFarmRepository = distributorFarmRepository;
    }

    // Obtener todas las relaciones
    public List<DistributorFarmId> getAllDistributorFarms() {
        return distributorFarmRepository.findAll();
    }

    // Obtener una relación por ID
    public Optional<DistributorFarmId> getDistributorFarmById(Long id) {
        return distributorFarmRepository.findById(id);
    }

    // Crear una nueva relación
    public DistributorFarmId createDistributorFarm(DistributorFarmId distributorFarm) {
        return distributorFarmRepository.save(distributorFarm);
    }

    // Eliminar una relación por ID
    public boolean deleteDistributorFarm(Long id) {
        if (distributorFarmRepository.existsById(id)) {
            distributorFarmRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
