package com.coffegrown.coffee.controller;

import com.coffegrown.coffee.model.coffeeOrder;
import com.coffegrown.coffee.servise.CoffeeOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/coffee-orders") // Ruta base del controlador
public class CoffeeOrderController {

    @Autowired
    private CoffeeOrderService coffeeOrderService;

    // Obtener todas las órdenes
    @GetMapping
    public List<CoffeeOrder> getAllOrders() {
        return coffeeOrderService.getAllOrders();
    }

    // Obtener una orden por ID
    @GetMapping("/{id}")
    public ResponseEntity<coffeeOrder> getOrderById(@PathVariable int id) {
        Optional<coffeeOrder> order = coffeeOrderService.getOrderById(id);
        return order.map(ResponseEntity::ok)
                    .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Crear una nueva orden
    @PostMapping
    public coffeeOrder createOrder(@RequestBody coffeeOrder coffeeOrder) {
        return coffeeOrderService.createOrder(coffeeOrder);
    }

    // Actualizar una orden
    @PutMapping("/{id}")
    public ResponseEntity<CoffeeOrder> updateOrder(@PathVariable int id, @RequestBody CoffeeOrder coffeeOrder) {
        coffeeOrder updatedOrder = coffeeOrderService.updateOrder(id, coffeeOrder);
        return updatedOrder != null ? ResponseEntity.ok(updatedOrder) : ResponseEntity.notFound().build();
    }

    // Eliminar una orden
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteOrder(@PathVariable int id) {
        boolean deleted = coffeeOrderService.deleteOrder(id);
        return deleted ? ResponseEntity.noContent().build() : ResponseEntity.notFound().build();
    }
}
