package com.coffegrown.coffee.model;

import jakarta.persistence.*;
import java.time.LocalDate; // Import para manejar fechas

@Entity
@Table(name = "coffee") // Corrección en el nombre de la tabla
public class CoffeeProduct { 

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "coffeeId")
    private Long coffeeId;

    @ManyToOne(cascade = CascadeType.ALL) // Agregada cascada opcional
    @JoinColumn(name = "processId", nullable = false)
    private CoffeeProcess process;

    @Column(name = "coffeeType", length = 100, nullable = false) // Corrección de nombre
    private String coffeeType;

    @Column(name = "quality", length = 50, nullable = false)
    private String quality;

    @Column(name = "variety", length = 50, nullable = false)
    private String variety;

    @Column(name = "harvestDate", nullable = false)
    private LocalDate harvestDate; // Cambio de String a LocalDate

    @Column(name = "foto", length = 100, nullable = false)
    private String foto;

    // Constructor vacío
    public CoffeeProduct() {}

    // Constructor con parámetros
    public CoffeeProduct(Long coffeeId, CoffeeProcess process, String coffeeType, String quality, 
                         String variety, LocalDate harvestDate, String foto) {
        this.coffeeId = coffeeId;
        this.process = process;
        this.coffeeType = coffeeType;
        this.quality = quality;
        this.variety = variety;
        this.harvestDate = harvestDate;
        this.foto = foto;
    }

    // Getters y Setters
    public Long getCoffeeId() { return coffeeId; }
    public void setCoffeeId(Long coffeeId) { this.coffeeId = coffeeId; }

    public CoffeeProcess getProcess() { return process; }
    public void setProcess(CoffeeProcess process) { this.process = process; }

    public String getCoffeeType() { return coffeeType; }
    public void setCoffeeType(String coffeeType) { this.coffeeType = coffeeType; }

    public String getQuality() { return quality; }
    public void setQuality(String quality) { this.quality = quality; }

    public String getVariety() { return variety; }
    public void setVariety(String variety) { this.variety = variety; }

    public LocalDate getHarvestDate() { return harvestDate; } // Cambio aquí
    public void setHarvestDate(LocalDate harvestDate) { this.harvestDate = harvestDate; }

    public String getFoto() { return foto; }
    public void setFoto(String foto) { this.foto = foto; }
}
