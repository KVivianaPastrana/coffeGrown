package com.coffegrown.coffee.controller;

import com.coffegrown.coffee.model.RegisterUsers;
import com.coffegrown.coffee.servise.RegisterUsersService;
import com.coffegrown.coffee.DTO.RegisterUsersDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/register")
public class RegisterUsersController {

    @Autowired
    private RegisterUsersService registerUsersService;

    // POST (REGISTER)
    @PostMapping
    public ResponseEntity<Object> registerUser(@RequestBody RegisterUsersDTO registerUsersDTO) {
        RegisterUsers registerUser = new RegisterUsers();
        registerUser.setName(registerUsersDTO.getName());
        registerUser.setEmail(registerUsersDTO.getEmail());
        registerUser.setPassword(registerUsersDTO.getPassword());
        registerUser.setProducer(registerUsersDTO.getProducer());
        registerUser.setRegisterDate(registerUsersDTO.getRegisterDate());

        registerUsersService.save(registerUsersDTO);

        return new ResponseEntity<>("User registered successfully", HttpStatus.CREATED);
    }
}
