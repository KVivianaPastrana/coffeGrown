
package com.coffegrown.coffee.model;


import jakarta.persistence.*;

@Entity
@Table(name = "coffee_order") // Mejor usar snake_case para evitar problemas
public class coffeeOrder {

    @Id
    @Column(name = "order_id")
    private int orderId;

    @Column(name = "coffee_id", nullable = false) // Mejor definir siempre nullable
    private int coffeeId;

    // Constructor vacío requerido por Hibernate
    public coffeeOrder() {}

    // Constructor con parámetros
    public coffeeOrder(int orderId, int coffeeId) {
        this.orderId = orderId;
        this.coffeeId = coffeeId;
    }

    // Getters y Setters
    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getCoffeeId() {
        return coffeeId;
    }

    public void setCoffeeId(int coffeeId) {
        this.coffeeId = coffeeId;
    }
}


/*
 * create table coffeeOrder (
 *     order_id INT PRIMARY KEY,
 *     coffeeId INT NOT NULL
 */