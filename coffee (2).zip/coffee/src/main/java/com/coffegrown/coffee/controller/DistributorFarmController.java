package com.coffegrown.coffee.controller;

import com.coffegrown.coffee.model.DistributorFarmId;
import com.coffegrown.coffee.repository.DistributorFarmRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/distributor-farms")
public class DistributorFarmController {

    @Autowired
    private DistributorFarmRepository distributorFarmRepository;

    // Obtener todas las relaciones
    @GetMapping
    public List<DistributorFarm> getAllDistributorFarms() {
        return distributorFarmRepository.findAll();
    }

    // Obtener una relación por ID
    @GetMapping("/{id}")
    public Optional<DistributorFarm> getDistributorFarmById(@PathVariable Long id) {
        return distributorFarmRepository.findById(id);
    }

    // Crear una nueva relación
    @PostMapping
    public DistributorFarm createDistributorFarm(@RequestBody DistributorFarm distributorFarm) {
        return distributorFarmRepository.save(distributorFarm);
    }

    // Eliminar una relación por ID
    @DeleteMapping("/{id}")
    public void deleteDistributorFarm(@PathVariable Long id) {
        distributorFarmRepository.deleteById(id);
    }
}
