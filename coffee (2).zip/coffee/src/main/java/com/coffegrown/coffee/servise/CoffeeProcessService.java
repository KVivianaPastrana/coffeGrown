package com.coffegrown.coffee.servise;

import com.coffegrown.coffee.model.CoffeeProcess;
import com.coffegrown.coffee.repository.CoffeeProcessRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CoffeeProcessService {

    private final CoffeeProcessRepository coffeeProcessRepository;


    public CoffeeProcessService(CoffeeProcessRepository coffeeProcessRepository) {
        this.coffeeProcessRepository = coffeeProcessRepository;
    }

    // Obtener todos los procesos de café
    public List<CoffeeProcess> getAllProcesses() {
        return coffeeProcessRepository.findAll();
    }

    // Obtener un proceso por ID
    public Optional<CoffeeProcess> getProcessById(int id) {
        return coffeeProcessRepository.findById(id);
    }

    // Crear un nuevo proceso
    public CoffeeProcess createProcess(CoffeeProcess process) {
        return coffeeProcessRepository.save(process);
    }

    // Actualizar un proceso existente
    public CoffeeProcess updateProcess(int id, CoffeeProcess updatedProcess) {
        return coffeeProcessRepository.findById(id).map(existingProcess -> {
            existingProcess.setType(updatedProcess.getType());
            existingProcess.setDurationH(updatedProcess.getDurationH());
            existingProcess.setMethod(updatedProcess.getMethod());
            return coffeeProcessRepository.save(existingProcess);
        }).orElse(null);
    }

    // Eliminar un proceso
    public boolean deleteProcess(int id) {
        if (coffeeProcessRepository.existsById(id)) {
            coffeeProcessRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
