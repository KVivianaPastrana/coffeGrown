package com.coffegrown.coffee.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="proces") // Nombre de la tabla en la base de datos
public class CoffeeProcess { // Cambio de nombre para evitar conflicto con Process

    @Id
    @Column(name="processId") 
    private int processId;
    
    @Column(name="type", length=100, nullable=false)
    private String type;

    @Column(name="durationH", length=50, nullable=false)
    private String durationH;
    
    @Column(name="method", length=100, nullable=false)
    private String method;

    // Constructor vacío (requerido por JPA)
    public CoffeeProcess() {
    }

    // Constructor con parámetros
    public CoffeeProcess(int processId, String type, String durationH, String method) {
        this.processId = processId;
        this.type = type;
        this.durationH = durationH;
        this.method = method;
    }

    // Getters y Setters
    public int getProcessId() {
        return processId;
    }

    public void setProcessId(int processId) {
        this.processId = processId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDurationH() {
        return durationH;
    }

    public void setDurationH(String durationH) {
        this.durationH = durationH;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }
}

