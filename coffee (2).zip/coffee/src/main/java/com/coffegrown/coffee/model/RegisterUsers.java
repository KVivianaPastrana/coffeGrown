package com.coffegrown.coffee.model;

import jakarta.persistence.*;

@Entity
@Table(name = "register_user")
public class RegisterUsers {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "registerId")
    private int registerId;

    @Column(name = "name", nullable = false, length = 100)
    private String name;

    @Column(name = "email", nullable = false, unique = true, length = 150)
    private String email;

    @Column(name = "password", nullable = false, length = 255)
    private String password;

    @ManyToOne
    @JoinColumn(name = "producer_id", nullable = false)
    private CoffeeProducers producer;

    @Column(name = "registerDate", nullable = false)
    private String registerDate;

    public RegisterUsers() {}

    public RegisterUsers(String name, String email, String password, CoffeeProducers producer, String registerDate) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.producer = producer;
        this.registerDate = registerDate;
    }

    // Getters y Setters
    public int getRegisterId() { return registerId; }
    public void setRegisterId(int registerId) { this.registerId = registerId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public CoffeeProducers getProducer() { return producer; }
    public void setProducer(CoffeeProducers producer) { this.producer = producer; }

    public String getRegisterDate() { return registerDate; }
    public void setRegisterDate(String registerDate) { this.registerDate = registerDate; }
}

/*
 * create table register(
 * registerId int(11) PK,
 * foreign key (producer_id) references producer(producer_id),
 * registerDate  DateTIME not null
 * );
 */