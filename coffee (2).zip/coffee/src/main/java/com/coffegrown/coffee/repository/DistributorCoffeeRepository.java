package com.coffegrown.coffee.repository;

import com.coffegrown.coffee.model.distributorCoffee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DistributorCoffeeRepository extends JpaRepository<distributorCoffee, Integer> {
    // Puedes agregar métodos personalizados si es necesario
}
