package com.coffegrown.coffee.DTO;

public class OrderCoffeeDTO {
    private int orderId;
    private String transportId;
    private String orderDate;
    private String amountKg;
    private String price;
    private String status;

    // Constructor vacío
    public OrderCoffeeDTO() {
    }

    // Constructor con parámetros
    public OrderCoffeeDTO(int orderId, String transportId, String orderDate, String amountKg, String price, String status) {
        this.orderId = orderId;
        this.transportId = transportId;
        this.orderDate = orderDate;
        this.amountKg = amountKg;
        this.price = price;
        this.status = status;
    }

    // Getters y Setters
    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public String getTransportId() {
        return transportId;
    }

    public void setTransportId(String transportId) {
        this.transportId = transportId;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public String getAmountKg() {
        return amountKg;
    }

    public void setAmountKg(String amountKg) {
        this.amountKg = amountKg;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
