package com.coffegrown.coffee.model;

import jakarta.persistence.*;

@Entity
@Table(name = "farms")
public class Farms {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Asegura que el ID se genera automáticamente
    private Integer farm_id;

    private String farmName;
    private String location;
    private Integer altitude; // Cambiado a Integer
    private Integer sizeH;    // Cambiado a Integer

    // Getters y Setters
    public Integer getFarm_id() {
        return farm_id;
    }

    public void setFarm_id(Integer farm_id) {
        this.farm_id = farm_id;
    }

    public String getFarmName() {
        return farmName;
    }

    public void setFarmName(String farmName) {
        this.farmName = farmName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Integer getAltitude() { // Devuelve un número en lugar de un string
        return altitude;
    }

    public void setAltitude(Integer altitude) {
        this.altitude = altitude;
    }

    public Integer getSizeH() { // Devuelve un número en lugar de un string
        return sizeH;
    }

    public void setSizeH(Integer sizeH) {
        this.sizeH = sizeH;
    }
}
