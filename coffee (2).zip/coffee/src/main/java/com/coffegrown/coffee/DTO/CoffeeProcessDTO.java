package com.coffegrown.coffee.DTO;

public class CoffeeProcessDTO {

    private int processId;
    private String type;
    private String durationH;
    private String method;

    // Constructor vacío
    public CoffeeProcessDTO() {}

    // Constructor con parámetros
    public CoffeeProcessDTO(int processId, String type, String durationH, String method) {
        this.processId = processId;
        this.type = type;
        this.durationH = durationH;
        this.method = method;
    }

    // Getters y Setters
    public int getProcessId() {
        return processId;
    }

    public void setProcessId(int processId) {
        this.processId = processId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDurationH() {
        return durationH;
    }

    public void setDurationH(String durationH) {
        this.durationH = durationH;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }
}
