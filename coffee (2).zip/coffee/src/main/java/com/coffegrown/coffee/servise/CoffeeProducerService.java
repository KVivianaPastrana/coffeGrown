package com.coffegrown.coffee.servise;

import org.springframework.stereotype.Service;

import com.coffegrown.coffee.DTO.CoffeeProducerDTO;
import com.coffegrown.coffee.model.CoffeeProducers;
import com.coffegrown.coffee.model.Farms;
import com.coffegrown.coffee.repository.CoffeeProducerRepository;
import com.coffegrown.coffee.repository.FarmRepository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CoffeeProducerService {

    private final FarmRepository farmRepository;
    private final CoffeeProducerRepository coffeeProducerRepository;

    // 💡 Inyección de dependencias por constructor (Recomendada)
    
    public CoffeeProducerService(FarmRepository farmRepository, CoffeeProducerRepository coffeeProducerRepository) {
        this.farmRepository = farmRepository;
        this.coffeeProducerRepository = coffeeProducerRepository;
    }

    // Guardar o actualizar farm
    public void save(Farms farm) {
        farmRepository.save(farm);
    }

    // Guardar o actualizar CoffeeProducer
    public void save(CoffeeProducerDTO coffeeProducerDTO) {
        CoffeeProducers producerToSave = convertToModel(coffeeProducerDTO);
        coffeeProducerRepository.save(producerToSave);
    }

    // Obtener todos los productores
    public List<CoffeeProducerDTO> findAll() {
        List<CoffeeProducers> producers = coffeeProducerRepository.findAll();
        return producers.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    // Buscar productor por ID
    public CoffeeProducerDTO findById(Long id) {
        Optional<CoffeeProducers> producer = coffeeProducerRepository.findById(id);
        return producer.map(this::convertToDTO).orElse(null);
    }

    // Eliminar productor
    public void delete(Long id) {
        coffeeProducerRepository.deleteById(id);
    }

    // Convertir DTO a Modelo
    private CoffeeProducers convertToModel(CoffeeProducerDTO coffeeProducerDTO) {
        CoffeeProducers producer = new CoffeeProducers();
        producer.setProducerName(coffeeProducerDTO.getProducerName());
        producer.setCertification(coffeeProducerDTO.getCertification());
        producer.setPassword(coffeeProducerDTO.getPassword());
        producer.setContact(coffeeProducerDTO.getContact());
        producer.setFarm(coffeeProducerDTO.getFarm()); 
        return producer;
    }

    // Convertir Modelo a DTO
    private CoffeeProducerDTO convertToDTO(CoffeeProducers producer) {
        return new CoffeeProducerDTO(
                producer.getProducerName(),
                producer.getCertification(),
                producer.getPassword(),
                producer.getContact(),
                producer.getFarm() 
        );
    }
}
