package com.coffegrown.coffee.model;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table; // Opcional, pero recomendable
@Entity
@Table(name="orders")
public class OrderCoffee { // Nombre de clase con mayúscula inicial
    @Id
    @Column(name="order_id")
    private int order_id;
    
    @Column(name="transportId", length=50, nullable=false)
    private String transportId;

    @Column(name="order_date", length=50, nullable=false)
    private String order_date;

    @Column(name="amountKg", length=50, nullable=false)
    private String amountKg;

    @Column(name="price", length=50, nullable=false)
    private String price;

    @Column(name="status", length=50, nullable=false)
    private String status;

    // Constructor vacío
    public OrderCoffee() {
    }

    // Constructor con parámetros
    public OrderCoffee(int order_id, String transportId, String order_date, String amountKg, String price, String status) {
        this.order_id = order_id;
        this.transportId = transportId;
        this.order_date = order_date;
        this.amountKg = amountKg;
        this.price = price;
        this.status = status;
    }

    // Getters y Setters
    public int getOrder_id() {
        return order_id;
    }

    public void setOrder_id(int order_id) {
        this.order_id = order_id;
    }

    public String getTransportId() {
        return transportId;
    }

    public void setTransportId(String transportId) {
        this.transportId = transportId;
    }

    public String getOrder_date() {
        return order_date;
    }

    public void setOrder_date(String order_date) {
        this.order_date = order_date;
    }

    public String getAmountKg() {
        return amountKg;
    }

    public void setAmountKg(String amountKg) {
        this.amountKg = amountKg;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}









/*
*
Create table Orders (
    order_id INT PRIMARY KEY,
    transportId INT,
    order_date VARCHAR(50),
    amountKg VARCHAR(50),
    price VARCHAR(50),
    status VARCHAR(50)
);
*/